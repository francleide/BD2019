const pool = require('../Config/db.js');
const crypt = require('../Config/crypt.js');

//nada por enquanto